Hello Michael,

Task is done, we tried to copy the terminal functions as best as we could including answering the requierments you have given us.

wc < text.txt          - (if exists) works if not not
man string > text.txt  - works

we also tested and applied in our code the "extreme" cases of arguments order:
for example:

< text.txt wc
< text.txt 					-both when file exists and not
> wc or > text.txt  		-doesnt matter if exists.
< wc
wc <


also multiple arguments like:

wc shell.c shell.c > text.txt shell.c shell.o
wc text.txt < text.txt text.txt shell.c


also single arguments like just:

wc 		-works
man 	-works
cat 	-works


and ofcourse full paths works or not depending if you gave us the right path or not.

***note***
we'v tried to break our program as much as we could or whatever arguments order we could think of, and tried to copy the correct errors in each case, if something works not as expected as it should by the normal terminal then, everything has a limit, even students lol.

Best regards~ Eran and Sasha

