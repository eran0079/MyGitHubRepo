#include <ctype.h>
#include <errno.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <signal.h>
#include <sys/wait.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>

#include "tokenizer.h"

/* Convenience macro to silence compiler warnings about unused function parameters. */
#define unused __attribute__((unused))

/* Whether the shell is connected to an actual terminal or not. */
bool shell_is_interactive;

/* File descriptor for the shell input */
int shell_terminal;

/* Terminal mode settings for the shell */
struct termios shell_tmodes;

/* Process group id for the shell */
pid_t shell_pgid;

int cmd_exit(struct tokens *tokens);
int cmd_help(struct tokens *tokens);
int cmd_pwd(struct tokens *tokens);
int cmd_cd(struct tokens *tokens);
void sort_cmd(struct tokens *tokens);
int count_paths(char*,char);
char** build_full_path(char* ,int);
char** build_args(struct tokens *tokens ,int);
void execute(char** );



/* Built-in command functions take token array (see parse.h) and return int */
typedef int cmd_fun_t(struct tokens *tokens);

/* Built-in command struct and lookup table */
typedef struct fun_desc {
  cmd_fun_t *fun;
  char *cmd;
  char *doc;
} fun_desc_t;

fun_desc_t cmd_table[] = {
  {cmd_help, "?", "show this help menu"},
  {cmd_exit, "exit", "exit the command shell"},
  {cmd_pwd, "pwd", "show current working directory"},
  {cmd_cd, "cd", "change the current working directory using an argument to another directory"}
};

/* Prints a helpful description for the given command */
int cmd_help(unused struct tokens *tokens) {
  for (unsigned int i = 0; i < sizeof(cmd_table) / sizeof(fun_desc_t); i++)
    printf("%s - %s\n", cmd_table[i].cmd, cmd_table[i].doc);
  return 1;
}

/* Exits this shell */
int cmd_exit(unused struct tokens *tokens) {
  exit(0);
}
/* pwd */
int cmd_pwd(unused struct tokens *tokens) {
char dir[4096];
getcwd(dir,sizeof(dir));
  printf("current working directory- %s\n",dir);
  return 1;
}
/*cd*/
int cmd_cd(unused struct tokens *tokens) {
int ret = chdir(tokens_get_token(tokens,1));
if(ret<0) printf("no such file or directoryERR1\n");

  return ret;
}
/*Sorting which type of arguments we are dealing with*/
void sort_cmd(unused struct tokens *tokens){

        pid_t pid=fork();

        if (pid == -1)
        {
            printf("fork failed\n");
        }
        else if (pid == 0)
        {       //if im a child - i got chores to do.
                int inner_length=0;
                size_t length_arg = tokens_get_length(tokens);
               //allocate all the argvs from tokens into an array. @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                char** argv = (char**)malloc(sizeof(char*)*length_arg+1);
                int i=0;
                //malloc argv
                for(i = 0;i<length_arg;i++){
                    inner_length = strlen(tokens_get_token(tokens,i));
                    inner_length=inner_length+1;
                    argv[i]=(char*)malloc((inner_length));
                    strcpy(argv[i],tokens_get_token(tokens,i));
                    argv[i][inner_length]='\0'; // make sure the last char is '\0';
                }
                argv[length_arg] ='\0'; //make sure there is another arg at the end which is null.
                //done allocating @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

                // running through argv to check special signs #######################################################################################
                for(i=0; i< length_arg; i++){       //run through the args and check if there is "<" or ">" in them. 3 case scenario here!
                    if(strcmp(argv[i],"<")==0){     //2 cases for "<" sign

                        int res= access(argv[i+1],F_OK);    //check if file exists to beging with.
                        if(res<0){
                            if(argv[i+1]== NULL){
                                printf("Shell: syntax error near unexpected token 'new line'\n");
                            }
                            else{
                                printf("Shell: %s: no such file or directory\n",argv[i+1]);
                            }
                            //free original argv
                            for(i = 0;i<length_arg;i++){
                                free(argv[i]);
                            }
                            free(argv);
                            exit(0);
                        }

                        if(length_arg == 3){        //1st case is there are only 3 arguments total. which leads to STDIN
                            //the stdin becomes the file content.
                            char** argv2 = build_args(tokens,i);    //create new argv which contains less args. (due to stdin file)
                            int fd = open(argv[i+1],O_RDONLY,0644); //open existing file. (not creating new 1 incase);
                            fflush(STDIN_FILENO);                   //fflushing whatever was in a buffer before.
                            dup2(fd,0);             //change stdin to a our file.
                            close(fd);

                            execute(argv2);
                            //free new args = argv2
                            for(i = 0;i<length_arg-2;i++){
                                free(argv2[i]);
                            }
                            free(argv2);
                            //free original argv
                            for(i = 0;i<length_arg;i++){
                                free(argv[i]);
                            }
                            free(argv);
                            exit(0);
                        }
                        else{                       // 2nd case, 4 and more arguments.
                            char** argv2 = build_args(tokens,i); //create new argv which contains less args. (due to stdin file)
                            execute(argv2);

                            //free new args = argv2
                            for(i = 0;i<length_arg-2;i++){
                                free(argv2[i]);
                            }
                            free(argv2);
                            //free original argv
                            for(i = 0;i<length_arg;i++){
                                free(argv[i]);
                            }
                            free(argv);
                            exit(0);
                        }
                    } //checking for ">"
                    else if(strcmp(argv[i],">")==0){
                        char** argv2 = build_args(tokens,i);     //create new argv which contains less args (due to stdout file)
                                                                        // 0644 - mode_t that allows read+write afterwards(or so it seems if we remove it)
                        int fd = open(argv[i+1], O_CREAT |O_WRONLY | O_TRUNC,0644); //equal to creat()
                        dup2(fd,1);         //change the STDOUT to a file.
                        close(fd);

                        execute(argv2);

                        //free new args = argv2
                        for(i = 0;i<length_arg-2;i++){
                            free(argv2[i]);
                        }
                        free(argv2);
                        //free original argv
                        for(i = 0;i<length_arg;i++){
                            free(argv[i]);
                        }
                        free(argv);
                        exit(0);
                    }
                }//done checking for special signs ######################################################################################################
                //no special signs found
                execute(argv); //execute a program with all its arguments.

                //free original argv
                for(i = 0;i<length_arg;i++){
                    free(argv[i]);
                }
                free(argv);
                exit(0);
        }
        else{
        //  if im the father, i wait.
            int status;
            wait(&status);
        }

}
/* Execute the programs with args */
void execute(char**  argv){
    char first = argv[0][0]; //save the 1st letter of the 1st word

    if(first != '/'){       //if its '/' its path, else its not. checking if its NOT '/'
        int j=0,cnt_paths=0;
        char* path= (char*)calloc(1,sizeof(char)*256);
        path = strcpy(path,getenv("PATH"));             //copy the path
        cnt_paths= count_paths(path,':'); //function that counts arguments in a path.
        char** splited_paths= build_full_path(argv[0],cnt_paths);   //if its not a path we will build a full path out of it, or try to.

        for(j=0; j<cnt_paths;j++){
            int res= access(splited_paths[j],F_OK);     //test if the path really exists before we try and execute it.
            if(res>=0){
                int ret= execv(splited_paths[j],argv);  //if it does exist, we execute
                if(ret<0){
                    printf("execution failed\n");                  //and check if it worked.
                    }
                }
        }
        printf("%s: command not found\n",argv[0]);  //if we did not find any, that command does not exist.
    }
    // full path given
    else{
        int ret = execv(argv[0],argv);      //try run the path given, if fails, no such path.
        if(ret<0){
            printf("No such file or directory\n");
        }
    }
}

/*Counting chars in a string*/
int count_paths(char* str,char c){ //simply check how many times char appears in string, to count paths.
    int i=0,cnt=0;
    for(i=0;i<strlen(str);i++){
        if(str[i]==c){
            cnt++;
        }
    }
    return cnt+1;
}

/*building full path*/
char** build_full_path(char* argv, int cnt_words){

    int i=0;
    char* path= (char*)calloc(1,sizeof(char)*256);
    path = strcpy(path,getenv("PATH"));                 //copying path string

    char** split_paths=(char**)malloc(sizeof(char*)*cnt_words);     //alocating enough space for all paths possible

    //using strtok to split all the path into tokens, and for each tokken we end "/" and "program name" at the end > aka full path.%%%%%%%%%%%%%%%%%%%%
    char temp[256]={0};
    path=strtok(path,":");
    strcpy(temp,path);
    strcat(temp,"/");
    strcat(temp,argv);
    split_paths[i]=(char*)malloc(sizeof(char)*strlen(temp)+1);
    strcpy(split_paths[i],temp);

    for(i=1;i<cnt_words;i++){
        path=strtok(NULL,":");
        strcpy(temp,path);
        strcat(temp,"/");
        strcat(temp,argv);
        split_paths[i]=(char*)malloc(sizeof(char)*strlen(temp)+1);
        strcpy(split_paths[i],temp);
    }
    //done spliting paths %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    return split_paths; //return the full paths we build, so the function above can run 1 by 1 and test if they exist.
}

/*Build special new arguments incase we found "<" or ">" inside the originals 1*/
char** build_args(unused struct tokens *tokens, int i){
    int j=0, k=0, inner_length = 0;
    int length_arg = tokens_get_length(tokens)-2; //we make 2 less arguments due to "<" or ">" and what comes after.
    char** argv = (char**)malloc(sizeof(char*)*length_arg+1);   //alocate enough space

    //malloc argv
    for(j = 0,k=0;j<length_arg;j++,k++){                //allocate each argument, except when j=i which is the index arg "<" or ">" at, so we skip 2 spots. thus -2 args.
        if(j == i) k+=2;
        inner_length = strlen(tokens_get_token(tokens,k));
        inner_length=inner_length+1;
        argv[j]=(char*)malloc((inner_length));
        strcpy(argv[j],tokens_get_token(tokens,k));
        argv[j][inner_length]='\0';
    }
    argv[length_arg] ='\0';         //again make sure the last argument in null.

    return argv;    //return the new allocated arguments.
}


/* Looks up the built-in command, if it exists. */
int lookup(char cmd[]) {
  for (unsigned int i = 0; i < sizeof(cmd_table) / sizeof(fun_desc_t); i++)
    if (cmd && (strcmp(cmd_table[i].cmd, cmd) == 0))
      return i;
  return -1;
}

/* Intialization procedures for this shell */
void init_shell() {
  /* Our shell is connected to standard input. */
  shell_terminal = STDIN_FILENO;

  /* Check if we are running interactively */
  shell_is_interactive = isatty(shell_terminal);

  if (shell_is_interactive) {
    /* If the shell is not currently in the foreground, we must pause the shell until it becomes a
     * foreground process. We use SIGTTIN to pause the shell. When the shell gets moved to the
     * foreground, we'll receive a SIGCONT.  our explain: if i call a func like WC, i go to sleep until its done.  */
    while (tcgetpgrp(shell_terminal) != (shell_pgid = getpgrp()))
      kill(-shell_pgid, SIGTTIN);

    /* Saves the shell's process id */
    shell_pgid = getpid();

    /* Take control of the terminal */
    tcsetpgrp(shell_terminal, shell_pgid);

    /* Save the current termios to a variable, so it can be restored later. */
    tcgetattr(shell_terminal, &shell_tmodes);
  }
}

int main(unused int argc, unused char *argv[]) {
  init_shell();

  static char line[4096];
  int line_num = 0;

  /* Please only print shell prompts when standard input is not a tty */
  if (shell_is_interactive)
    fprintf(stdout, "%d: ", line_num);

  while (fgets(line, 4096, stdin)) {
    /* Split our line into words. */
    struct tokens *tokens = tokenize(line);

    /* Find which built-in function to run. */
    int fundex = lookup(tokens_get_token(tokens, 0));

    if (fundex >= 0) {
      cmd_table[fundex].fun(tokens);
    } else {
      /* REPLACE this to run commands as programs.
      fprintf(stdout, "This shell doesn't know how to run programs.\n");*/
      sort_cmd(tokens);
    }

    if (shell_is_interactive)
      /* Please only print shell prompts when standard input is not a tty */
      fprintf(stdout, "%d: ", ++line_num);

    /* Clean up memory */
    tokens_destroy(tokens);
  }

  return 0;
}
